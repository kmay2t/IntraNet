<?php

declare(strict_types=1);

header('Content-Type: text/html; charset=UTF-8');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'none'; connect-src 'none'; form-action 'none'; base-uri 'none'; frame-ancestors 'self'");

$cards = [
    [
        'title' => 'Consulta de reportes',
        'description' => 'Busca, descarga y edita reportes de Patología (Especialidades y Ginecología).',
    ],
    [
        'title' => 'Visor de estudios DICOM',
        'description' => 'Busca y descarga estudios DICOM desde el PACS (C-FIND / C-MOVE).',
    ],
    [
        'title' => 'Envío de estudios DICOM',
        'description' => 'Sube carpetas de estudios DICOM a un nodo PACS con C-STORE, y —si tienes permiso— trae estudios de otro nodo y reenvíalos.',
    ],
    [
        'title' => 'Consulta lista de trabajo',
        'description' => 'Consulta los procedimientos programados de un nodo (MWL), filtra por nombre, ID, fecha, hora, modalidad y procedimiento, y manda la prueba de conexión o de imagen.',
    ],
];

$escape = static fn (?string $value): string => htmlspecialchars(
    $value ?? '',
    ENT_QUOTES | ENT_SUBSTITUTE,
    'UTF-8'
);

?>
<!doctype html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="referrer" content="no-referrer">
    <title>Sistemas Médicos · meditechnosys</title>
    <link rel="icon" href="assets/favicon.ico">
    <link rel="stylesheet" href="assets/css/portal.css?v=1.0.0">
</head>
<body>
    <div class="shell">
        <header class="site-header">
            <div class="brand" aria-label="meditechnosys">
                <span class="brand-name">medi<span>technosys</span></span>
                <span class="brand-subtitle">Medical Technology Solutions</span>
            </div>
            <span class="internal-badge">Uso interno</span>
        </header>

        <main id="contenido">
            <section class="medical-systems" aria-labelledby="sistemas-medicos">
                <div class="section-heading">
                    <h1 id="sistemas-medicos">Sistemas médicos</h1>
                </div>
                <p class="section-intro">Catálogo informativo de los sistemas médicos.</p>

                <div class="cards">
                    <?php foreach ($cards as $card): ?>
                        <article class="card">
                            <p class="card-tag">Sistemas médicos</p>
                            <h2><?= $escape($card['title']) ?></h2>
                            <p class="card-description"><?= $escape($card['description']) ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            </section>
        </main>

        <footer class="site-footer">
            <span>meditechnosys · meditechnosys.mx</span>
            <span>Portal informativo · Versión 1.0.0</span>
        </footer>
    </div>
</body>
</html>
